import numpy as np
import os
import imageio

file = "one_plane_video3.npy"
frames = np.load(file) 

imageio.mimsave(
    "plane_sim.mp4",
    frames,
    fps=30
)